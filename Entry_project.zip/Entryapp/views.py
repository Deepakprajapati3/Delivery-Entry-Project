from django.shortcuts import render
from django.http import HttpResponseForbidden
from django.utils import timezone
from django.shortcuts import render, redirect
from .forms import ParcelForm
from .models import Parcel

def create_parcel(request):
    if request.method == 'POST':
        form = ParcelForm(request.POST)
        if form.is_valid():
            form.save()  # Saves the form data to the database
            return redirect('add_parcel')  # Replace 'success' with your success page or URL name
    else:
        form = ParcelForm()

    return render(request, 'home.html', {'form': form})



def show_data(request):
    date = request.GET.get('date')
    flat_no = request.GET.get('flat_no')
    
    data =Parcel.objects.all().order_by('-id')
        # if provided 
    if date:
        data = Parcel.objects.filter(date=date)
        # if provided
    if flat_no:
        data = Parcel.objects.filter(flat_no=flat_no)
    
    return render(request,'parcel_list.html',{'data':data})



def delete(request,id):
    if not request.user.is_superuser:
        return HttpResponseForbidden("You do not have permission to Delete  Data.")
    else:
       d = Parcel.objects.get(pk=id)
       d.delete()
       return redirect('/show_data')




def update(request, id):
    if not request.user.is_superuser:
        return HttpResponseForbidden("You do not have permission to Update  Data.")
    else:
       pi = Parcel.objects.get(pk=id)
       if request.method == 'POST':
           form = ParcelForm(request.POST,instance=pi)
           if form.is_valid():
               form.save()
               return redirect('/show_data')
       else:
          pi=Parcel.objects.get(pk=id)
          form = ParcelForm(instance=pi)
          return render(request,'update.html',{'form':form})
    
