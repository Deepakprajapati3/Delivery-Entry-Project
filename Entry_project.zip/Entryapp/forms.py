from django import forms
from .models import Parcel

class ParcelForm(forms.ModelForm):
    class Meta:
        model = Parcel
        fields = ['name', 'mobile_number', 'parcel_from', 'parcel_to', 'flat_no']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter your name'}),
            'mobile_number': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter your mobile number'}),
            'parcel_from': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Parcel from'}),
            'parcel_to': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Parcel to'}),
            'flat_no': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Flat number',}),
        }
        
        

    