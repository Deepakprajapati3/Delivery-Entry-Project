from django.db import models

from django.db import models

class Parcel(models.Model):
    name = models.CharField(max_length=100)
    mobile_number = models.CharField(max_length=10)
    parcel_from = models.CharField(max_length=50)
    parcel_to = models.CharField(max_length=50)
    flat_no = models.CharField(max_length=2)
    date = models.DateField(auto_now=True)
    time = models.TimeField(auto_now=True)

    def __str__(self):
        return f"{self.name} - {self.parcel_from} to {self.parcel_to}"

