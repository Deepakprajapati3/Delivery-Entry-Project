
from django.contrib import admin
from django.urls import path
from . import views as v

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',v.create_parcel, name='add_parcel'),
    path('show_data',v.show_data, name ='show_data'),
    path('update/<int:id>/',v.update, name='update'),
    path('delete/<int:id>/',v.delete, name='delete')
    
]
