from django.contrib import admin
from .models import Parcel

class ParcelAdmin(admin.ModelAdmin):
      list_display = ['name', 'mobile_number', 'parcel_from', 'parcel_to', 'flat_no', 'date', 'time']

# Register the Parcel model with the custom admin configuration
admin.site.register(Parcel, ParcelAdmin)
